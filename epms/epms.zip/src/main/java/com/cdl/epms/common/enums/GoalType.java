package com.cdl.epms.common.enums;

public enum GoalType {
    PREDEFINED,
    SMART,
    DEVELOPMENT
}
