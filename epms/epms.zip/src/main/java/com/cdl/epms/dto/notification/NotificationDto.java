package com.cdl.epms.dto.notification;

public class NotificationDto {
}
