package com.cdl.epms.dto.goal;

public class GoalResponseDto {
}
