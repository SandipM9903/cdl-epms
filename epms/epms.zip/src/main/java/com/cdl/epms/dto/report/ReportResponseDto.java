package com.cdl.epms.dto.report;

public class ReportResponseDto {
}
