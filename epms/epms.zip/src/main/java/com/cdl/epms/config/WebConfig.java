package com.cdl.epms.config;

public class WebConfig {
}
