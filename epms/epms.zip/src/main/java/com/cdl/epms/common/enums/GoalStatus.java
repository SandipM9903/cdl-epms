package com.cdl.epms.common.enums;

public enum GoalStatus {
    DRAFT,
    SUBMITTED,
    APPROVED
}
