package com.cdl.epms.dto.review;

public class ReviewRequestDto {
}
