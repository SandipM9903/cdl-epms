package com.cdl.epms.common.enums;

public enum CycleType {
    QUARTERLY,
    ANNUAL
}