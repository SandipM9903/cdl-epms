package com.cdl.epms.model;

public class Quarter {
}
