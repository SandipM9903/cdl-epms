package com.cdl.epms.common.enums;

public enum CycleStatus {
    DRAFT,
    PUBLISHED,
    CLOSED
}