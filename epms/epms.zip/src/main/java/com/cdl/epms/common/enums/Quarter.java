package com.cdl.epms.common.enums;

public enum Quarter {
    Q1, Q2, Q3, Q4
}