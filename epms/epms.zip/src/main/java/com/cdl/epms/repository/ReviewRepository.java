package com.cdl.epms.repository;

public interface ReviewRepository {
}
