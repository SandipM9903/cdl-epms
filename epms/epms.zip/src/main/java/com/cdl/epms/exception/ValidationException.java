package com.cdl.epms.exception;

public class ValidationException {
}
